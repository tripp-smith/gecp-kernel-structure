import glob,json,hashlib,os,sys
from fractions import Fraction
import numpy as np
from pathlib import Path
root=Path('/tmp/gecp-maxent-lm-eeb5523-reports')
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def exact_rank(a):
 a=[[Fraction(float(x)) for x in row] for row in a]; m=len(a); n=len(a[0]); r=0
 for c in range(n):
  pivot=next((i for i in range(r,m) if a[i][c]),None)
  if pivot is None: continue
  a[r],a[pivot]=a[pivot],a[r]; t=a[r][c]; a[r]=[v/t for v in a[r]]
  for i in range(r+1,m):
   t=a[i][c]
   if t: a[i]=[x-t*y for x,y in zip(a[i],a[r])]
  r+=1
  if r==m: break
 return r
out={'schema':'gecp.lm-independent-audit.v1','python':sys.version,'numpy':np.__version__,'command':'OPENBLAS_NUM_THREADS=1 ./.venv/bin/python /tmp/gecp-lm-independent-1044.py','script_sha256':sha(__file__),'provider_sha256':sha('/tmp/gecp-eb-triqs-runtime/lib/python3.12/site-packages/triqs_maxent/minimizers/levenberg_minimizer.py'),'runs':[]}
for p in sorted(root.glob('*/result.json')):
 d=json.loads(p.read_text()); run={'name':p.parent.name,'result_sha256':sha(p),'trials':[]}
 for t in d['trials']:
  trial={'name':t['name'],'effective_mu0':t['effective_mu0'],'status':t['status'],'completed_history':sum(x.get('converged') is True for x in t.get('history',[])),'alpha_count':len(t.get('alphas',[])),'all_converged':all(t.get('converged',[])) if t.get('converged') else None}
  if t.get('failure'):
   trial['failure']={k:t['failure'].get(k) for k in ('i','mu','scalar_alpha','npz_sha256','caller_line')}
  run['trials'].append(trial)
 npz=p.with_name('result.failure.npz')
 if npz.exists():
  z=np.load(npz); A=z['matrix']; J=z['J']; b=z['rhs']; mu=float(z['mu']); Id=z['Id']; s=np.linalg.svd(A,compute_uv=False); x,res,rank,sl=np.linalg.lstsq(A,b,rcond=None); norm=np.linalg.norm(b)
  rec={'sha256':sha(npz),'shape':list(A.shape),'finite':bool(all(np.isfinite(z[k]).all() for k in z.files)),'mu':mu,'matrix_equals_float_J_plus_mu_Id':bool(np.array_equal(A,J+mu*Id)),'rhs_equals_f':bool(np.array_equal(b,z['f'])),'id_equals_identity':bool(np.array_equal(Id,np.eye(len(b)))),'unchanged_diagonal_count':int(np.sum(np.diag(A)==np.diag(J))),'diagonal_ulp':np.abs(np.spacing(np.diag(J))).tolist(),'diag_J':np.diag(J).tolist(),'matrix_singular_values':s.tolist(),'matrix_eigenvalues':[[float(v.real),float(v.imag)] for v in np.linalg.eigvals(A)],'matrix_exact_binary_rank':exact_rank(A),'augmented_exact_binary_rank':exact_rank(np.column_stack((A,b))),'lstsq_rank':int(rank),'lstsq_relative_residual':float(np.linalg.norm(A@x-b)/norm) if norm else None,'rhs_norm':float(norm),'asymmetry_max':float(np.max(np.abs(A-A.T))),'hypothetical_fixed_J':{}}
  for m in [1e-18,1e-12,1e-8]:
   B=J+m*Id; sv=np.linalg.svd(B,compute_uv=False)
   rec['hypothetical_fixed_J'][str(m)]={'unchanged_diagonal_count':int(np.sum(np.diag(B)==np.diag(J))),'singular_values':sv.tolist(),'condition_2':float(sv[0]/sv[-1]) if sv[-1]>0 else None,'exact_binary_rank':exact_rank(B)}
  run['captured_system']=rec
 out['runs'].append(run)
Path('/tmp/gecp-lm-independent-1044.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
for run in out['runs']:
 print(run['name'],[(t['name'],t['status'],t['completed_history'],t['failure']['mu'] if 'failure' in t else None) for t in run['trials']])
 if 'captured_system' in run:
  x=run['captured_system']; print('  mu',x['mu'],'J diag',x['diag_J'],'ulp',x['diagonal_ulp'],'eq',x['matrix_equals_float_J_plus_mu_Id'],'unchanged',x['unchanged_diagonal_count'],'rank',x['matrix_exact_binary_rank'],x['augmented_exact_binary_rank'],'sv',x['matrix_singular_values'],'relative_res',x['lstsq_relative_residual'],'hyp',[(k,v['unchanged_diagonal_count'],v['exact_binary_rank'],v['condition_2']) for k,v in x['hypothetical_fixed_J'].items()])
